'use strict';

module.exports = {
  components: {
    'getFoodMenu': require('./customComponents/getFoodMenu')
  }
};
